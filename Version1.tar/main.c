#include <stdio.h>
#include <stdlib.h>
#include "affichage.h"

int main(int argc, char* args[]){ 
    
    afficher_menu();
    
    return EXIT_SUCCESS; 
}
